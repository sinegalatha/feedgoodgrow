<?php
$servername = "localhost";
$username = "root";
$password = "";
$database="contact_page";
$conn = mysqli_connect($servername, $username, $password,$database);

if (!$conn) {
 echo " not Connected successfully "; 
}
$name=$_POST['name'];
$email=$_POST['email'];
$message=$_POST['sms'];
$sql="INSERT INTO `contact` (`name`, `email`, `message`) VALUES ('$name', '$email', '$message')";
$result=mysqli_query($conn,$sql);
if(isset($_POST['submit'])){

if($result)
  {
    header('location:contactpage.html');
  }
else{
  echo '<script>alert("Sorry! try again later.")</script>';
  include('contactpage.html');
}
}


?>