let sideNav = document.querySelector('.side-nav');
let  toggler = document.querySelector('.toggler');
let closeBtn = document.querySelector('.close-btn');

toggler.addEventListener('click', ()=>{
    sideNav.style.right = '0';
})


closeBtn.addEventListener('click', ()=> sideNav.style.right = '-100%');