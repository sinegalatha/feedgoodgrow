<?php
session_start();
$conn=mysqli_connect("localhost","root","","contact_page");
if(isset($_POST['dltbtn']))
{
    $all_id=$_POST['delete_id'];
    $extract_id=implode(',',$all_id);

    $query="DELETE FROM contact WHERE id IN($extract_id)";
    $query_run=mysqli_query($conn,$query);
    if($query_run){
        header("Location: customertable.php");
    }
    else{
        header("Location: customertable.php");
    }
}
?>