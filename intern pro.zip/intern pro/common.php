<?php

$email = $_POST['email'];

$password= $_POST['password'];

$con = new mysqli ("localhost", "root","","contact_page");
if ($con->connect_error) {

    die("Failed to connect : ".$con->connect_error);
    
    } else {
    
    $stmt = $con->prepare("select * from login where username = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    
    $stmt_result = $stmt->get_result();
    
    if($stmt_result->num_rows > 0) {
    
    $data = $stmt_result->fetch_assoc();
    if($data['Password']=== $password)
     { 
         include("customertable.php");
    
    }
     else {
    
        echo '<script>alert("Invalid Username or Password!")</script>';
        include("login.html");
    
    }
    
    } else {
    
        echo '<script>alert("Invalid Username or Password!")</script>';
        include("login.html");
    
    }
}
?>