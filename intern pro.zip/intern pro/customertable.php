<?php session_start();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>feedgoodagro</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="row text-center pt-5"><h4>Customer Details</h4></div></div>
             <div class="row pr-5">
            <button id="btnExport" class="btn btn-success ml-auto"><i class="fas fa-download"></i></button></div>
            <div class="col-md-12">
                <div class="card-mt-4">
                    <div class="card-body">
                        <form action="table.php" method="post">
                            <table class="table table-striped" id="tbl">
                                <tbody>
                                    <tr>
                                        <th><button type="submit" name="dltbtn" class="btn btn-danger"><i class="fas fa-trash"></i></button></th>
                                        <th>name</th>
                                        <th>email id</th>
                                        <th>message</th>
                                    </tr>
                                </tbody>
                                <tbody>
                                    <?php
                                    $conn = mysqli_connect("localhost","root","","contact_page");
                                    $query = "SELECT * FROM contact";
                                    $qrun = mysqli_query($conn,$query);
                                    if(mysqli_num_rows($qrun)>0)
                                    {
                                        foreach($qrun as $r)
                                        {
                                            ?>
                                            <tr>
                                            <td style="text-align:center;width:10px;">
                                            <input type="checkbox" name="delete_id[]" value="<?= $r['id']; ?>">
                                        </td>
                                            <td><?= $r['name']; ?></td>
                                            <td><?= $r['email']; ?></td>
                                            <td><?= $r['message']; ?></td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else{
                                        ?>
                                        <tr>
                                            <td colspan="5">
                                                No Record Found
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
    <script type="text/javascript">
        $("body").on("click", "#btnExport", function () {
            html2canvas($('#tbl')[0], {
                onrendered: function (canvas) {
                    var data = canvas.toDataURL();
                    var docDefinition = {
                        content: [{
                            image: data,
                            width: 500
                        }]
                    };
                    pdfMake.createPdf(docDefinition).download("cutomer-details.pdf");
                }
            });
        });
    </script>
</body>
</html>