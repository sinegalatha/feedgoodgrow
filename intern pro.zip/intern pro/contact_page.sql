SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
CREATE TABLE `contact` (
  `username` varchar(20) NOT NULL,
  `email` varchar(15) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `contact` (`username`, `email`, `message`) VALUES
('hi', 'asas', 'sadasdas'),
('root', 'sdfs', 'sdfs'),
('root', 'sdfs', 'sdfs'),
('root', 'mukeshnkl1777@g', 'hi'),
('root', 'mukeshnkl1777@g', 'hi'),
('mukesh', 'mukeshnkl1777@g', 'hi'),
('mukesh', 'mukeshnkl1777@g', 'hiiiiiiiii'),
('mukesh', 'mukeshnkl1777@g', 'hiiiiiiiii'),
('mukesh', 'mukeshnkl1777@g', 'hiiiiiiiii'),
('mukesh', 'mukeshnkl1777@g', 'hiiiiiiiii'),
('mukesh', 'mukeshnkl1777@g', 'hiiiiiiiii'),
('mukesh', 'mukeshnkl1777@g', 'hiiiiiiiii'),
('mukesh', 'mukeshnkl1777@g', 'hiiiiiiiii'),
('', '', ''),
('sad', 'asda', 'asda'),
('mukesh', 'mukeshnkl1777@g', 'hiiiiiiiii'),
('sdfsd', 'sdfs', 'sdfsd');
COMMIT;


